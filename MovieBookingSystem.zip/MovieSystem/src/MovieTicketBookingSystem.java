
import java.util.*;
import java.io.*;

class MovieTicketBookingSystem {

    static String[] movies    = {"Avatar", "Batman", "Dune", "Inception", "Joker", "Matrix", "Oppenheimer"};
    static double[] ratings   = {7.8, 7.2, 8.1, 9.3, 8.5, 8.7, 8.9};
    static int[]    prices    = {300, 150, 250, 400, 200, 350, 100};
    static String[] showtimes = {"09:00", "10:30", "12:00", "14:15", "16:30", "18:45", "21:00"};
    static int[] ratingCount = {0,0,0,0,0,0,0};

    static int vipSeatsBooked = 0;
    static final int MAX_VIP_SEATS = 20;

    static class BookingNode {
        int bookingID;
        String customerName, movie, showtime, ticketType;
        int seatNumber, price;
        BookingNode next;

        BookingNode(int id, String name, String movie, String showtime, int seat, int price, String ticketType) {
            this.bookingID = id;
            this.customerName = name;
            this.movie = movie;
            this.showtime = showtime;
            this.seatNumber = seat;
            this.price = price;
            this.ticketType = ticketType;
        }
    }

    static class BookingList {
        BookingNode head = null;
        int counter = 1001;

        // ===== FILE LOAD =====
        void loadFromFile() {
            try {
                BufferedReader br = new BufferedReader(new FileReader("bookings.txt"));
                String line;

                while ((line = br.readLine()) != null) {
                    String[] d = line.split(",");

                    BookingNode node = new BookingNode(
                        Integer.parseInt(d[0]), d[1], d[2], d[3],
                        Integer.parseInt(d[4]), Integer.parseInt(d[5]), d[6]
                    );

                    if (head == null) head = node;
                    else {
                        BookingNode temp = head;
                        while (temp.next != null) temp = temp.next;
                        temp.next = node;
                    }

                    if (node.bookingID >= counter)
                        counter = node.bookingID + 1;
                }

                br.close();
            } catch (Exception e) {
                System.out.println("No previous file found.");
            }
        }

        // ===== FILE SAVE =====
        void saveToFile() {
            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter("bookings.txt"));
                BookingNode temp = head;

                while (temp != null) {
                    bw.write(temp.bookingID + "," + temp.customerName + "," + temp.movie + "," +
                             temp.showtime + "," + temp.seatNumber + "," + temp.price + "," + temp.ticketType);
                    bw.newLine();
                    temp = temp.next;
                }

                bw.close();
            } catch (Exception e) {
                System.out.println("File write error");
            }
        }

        void addBooking(String name, String movie, String showtime, int seat, int price, String ticketType) {

            if (ticketType.equalsIgnoreCase("VIP")) {
                if (vipSeatsBooked >= MAX_VIP_SEATS) {
                    System.out.println("\n VIP seats are FULL!");
                    return;
                }
                vipSeatsBooked++;
            }

            BookingNode newNode = new BookingNode(counter++, name, movie, showtime, seat, price, ticketType);

            if (head == null) head = newNode;
            else {
                BookingNode temp = head;
                while (temp.next != null) temp = temp.next;
                temp.next = newNode;
            }

            System.out.println("\n Booking Confirmed!");
            System.out.println("   Booking ID : " + newNode.bookingID);

            saveToFile();   
        }

        void displayAll() {
            if (head == null) {
                System.out.println("\n No bookings found.");
                return;
            }

            System.out.println("\n All Bookings:");
            System.out.println("--------------------------------------------------------------");
            System.out.println("ID\tCustomer\tMovie\tTime\tSeat\tPrice\tType");
            System.out.println("--------------------------------------------------------------");

            BookingNode temp = head;
            while (temp != null) {
                System.out.println(temp.bookingID + "\t" +
                        temp.customerName + "\t\t" +
                        temp.movie + "\t" +
                        temp.showtime + "\t" +
                        temp.seatNumber + "\t" +
                        "Rs." + temp.price + "\t" +
                        temp.ticketType);
                temp = temp.next;
            }

            System.out.println("--------------------------------------------------------------");
        }

        void cancelBooking(int bookingID) {
            if (head == null) return;

            if (head.bookingID == bookingID) {
                head = head.next;
                saveToFile();
                return;
            }

            BookingNode prev = head, curr = head.next;

            while (curr != null) {
                if (curr.bookingID == bookingID) {
                    prev.next = curr.next;
                    saveToFile();
                    return;
                }
                prev = curr;
                curr = curr.next;
            }

            System.out.println("\n Booking ID not found.");
        }

        void viewPriorityQueue() {
            PriorityQueue<BookingNode> pq = new PriorityQueue<>(
                (a, b) -> a.bookingID - b.bookingID
            );

            BookingNode temp = head;
            while (temp != null) {
                pq.add(temp);
                temp = temp.next;
            }

            System.out.println("\n Priority Queue:");
            while (!pq.isEmpty()) {
                BookingNode b = pq.poll();
                System.out.println(b.bookingID + " " + b.customerName);
            }
        }
    }

    static int linearSearch(String target) {
        for (int i = 0; i < movies.length; i++) {
            if (movies[i].equalsIgnoreCase(target)) return i;
        }
        return -1;
    }

    static void showMovieList() {
        System.out.println("\n Available Movies:");
        System.out.println("------------------------------------------------");
        System.out.println("No.  Movie            Rating     Price    Time");
        System.out.println("------------------------------------------------");

        for (int i = 0; i < movies.length; i++) {
            String name = movies[i];
            while (name.length() < 16) name += " ";

            String rating = "Rating:" + ratings[i];
            while (rating.length() < 12) rating += " ";

            String price = "Rs." + prices[i];
            while (price.length() < 10) price += " ";

            System.out.println((i+1) + "    " + name + rating + price + showtimes[i]);
        }

        System.out.println("------------------------------------------------");
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        BookingList list = new BookingList();

        list.loadFromFile();   

        int choice;

        do {
            System.out.println("\n======================================");
            System.out.println("   MOVIE TICKET BOOKING SYSTEM        ");
            System.out.println("======================================");
            System.out.println("1.Search Movie");
            System.out.println("2.Show Movies");
            System.out.println("3.Sort Movies");
            System.out.println("4.Book Ticket");
            System.out.println("5.View Bookings");
            System.out.println("6.Search Booking");
            System.out.println("7.Cancel Booking");
            System.out.println("8.Priority Queue");
            System.out.println("9.Rate Movie");
            System.out.println("10.Exit");

            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    System.out.print("Enter Movie Name: ");
                    int idx = linearSearch(sc.nextLine());
                    if (idx != -1) {
                        System.out.println("Movie Found: " + movies[idx]);
                    } else {
                        System.out.println("Not found");
                        System.out.println("   Select option 2 for available movies.");
                    }
                    break;

                case 2:
                    showMovieList();
                    break;

                case 4:
                    showMovieList();
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Movie No: ");
                    int m = sc.nextInt() - 1;
                    System.out.print("Seat: ");
                    int seat = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Type: ");
                    String type = sc.nextLine();

                    list.addBooking(name, movies[m], showtimes[m], seat, prices[m], type);
                    break;

                case 5:
                    list.displayAll();
                    break;

                case 7:
                    System.out.print("Enter ID: ");
                    list.cancelBooking(sc.nextInt());
                    break;

                case 8:
                    list.viewPriorityQueue();
                    break;

                case 9:
                    System.out.print("Movie no: ");
                    int r = sc.nextInt() - 1;
                    System.out.print("Rating: ");
                    double nr = sc.nextDouble();

                    ratings[r] = ((ratings[r]*ratingCount[r]) + nr) / (ratingCount[r] + 1);
                    ratingCount[r]++;
                    break;

                case 10:
                    list.saveToFile();   
                    System.out.println("Thank you!");
                    break;
            }

        } while (choice != 10);

        sc.close();
    }
}