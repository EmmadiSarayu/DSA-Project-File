import java.io.*;

class BookingList {

    BookingNode head = null;
    int counter = 1001;

    BookingList() {
        loadFromFile();   
    }

    void addBooking(String name, String movie, String showtime, int seat, int price, String type) {

        BookingNode node = new BookingNode(counter++, name, movie, showtime, seat, price, type);

        if (head == null) head = node;
        else {
            BookingNode t = head;
            while (t.next != null) t = t.next;
            t.next = node;
        }

        System.out.println("Booking Confirmed! ID: " + node.bookingID);
        saveToFile();   
    }

    void displayAll() {
        BookingNode t = head;

        if (t == null) {
            System.out.println("No bookings");
            return;
        }

        while (t != null) {
            System.out.println(t.bookingID + " " + t.customerName + " " + t.movie);
            t = t.next;
        }
    }

    void cancelBooking(int id) {
        if (head == null) return;

        if (head.bookingID == id) {
            head = head.next;
            saveToFile();
            return;
        }

        BookingNode p = head, c = head.next;

        while (c != null) {
            if (c.bookingID == id) {
                p.next = c.next;
                saveToFile();
                return;
            }
            p = c;
            c = c.next;
        }

        System.out.println("Booking not found");
    }

    // ================= FILE LOAD =================
    void loadFromFile() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("bookings.txt"));
            String line;

            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");

                BookingNode node = new BookingNode(
                    Integer.parseInt(d[0]), d[1], d[2], d[3],
                    Integer.parseInt(d[4]), Integer.parseInt(d[5]), d[6]
                );

                if (head == null) head = node;
                else {
                    BookingNode temp = head;
                    while (temp.next != null) temp = temp.next;
                    temp.next = node;
                }

                if (node.bookingID >= counter)
                    counter = node.bookingID + 1;
            }

            br.close();
        } catch (Exception e) {
            System.out.println("No previous file found.");
        }
    }

    // ================= FILE SAVE =================
    void saveToFile() {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("bookings.txt"));
            BookingNode temp = head;

            while (temp != null) {
                bw.write(temp.bookingID + "," + temp.customerName + "," + temp.movie + "," +
                         temp.showtime + "," + temp.seatNumber + "," + temp.price + "," + temp.ticketType);
                bw.newLine();
                temp = temp.next;
            }

            bw.close();
        } catch (Exception e) {
            System.out.println("File write error");
        }
    }
}