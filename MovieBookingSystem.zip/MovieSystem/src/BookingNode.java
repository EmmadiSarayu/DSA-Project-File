
class BookingNode {
    int bookingID;
    String customerName, movie, showtime, ticketType;
    int seatNumber, price;
    BookingNode next;

    BookingNode(int id, String name, String movie, String showtime, int seat, int price, String type) {
        this.bookingID = id;
        this.customerName = name;
        this.movie = movie;
        this.showtime = showtime;
        this.seatNumber = seat;
        this.price = price;
        this.ticketType = type;
        this.next = null;
    }
}