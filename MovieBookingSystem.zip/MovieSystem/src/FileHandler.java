
import java.io.*;


class FileHandler {

    static BookingNode load() {
        BookingNode head = null, tail = null;

        try {
            BufferedReader br = new BufferedReader(new FileReader("bookings.txt"));
            String line;

            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");

                BookingNode node = new BookingNode(
                        Integer.parseInt(d[0]), d[1], d[2], d[3],
                        Integer.parseInt(d[4]), Integer.parseInt(d[5]), d[6]);

                if (head == null) head = tail = node;
                else {
                    tail.next = node;
                    tail = node;
                }
            }

            br.close();
        } catch (Exception e) {
            System.out.println("No previous file found");
        }

        return head;
    }

    static void save(BookingNode head) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("bookings.txt"));
            BookingNode t = head;

            while (t != null) {
                bw.write(t.bookingID + "," + t.customerName + "," + t.movie + "," +
                         t.showtime + "," + t.seatNumber + "," + t.price + "," + t.ticketType);
                bw.newLine();
                t = t.next;
            }

            bw.close();
        } catch (Exception e) {
            System.out.println("File error");
        }
    }
}
