
class MovieData {

    static String[] movies = {"Avatar", "Batman", "Dune", "Inception", "Joker", "Matrix", "Oppenheimer"};
    static double[] ratings = {7.8, 7.2, 8.1, 9.3, 8.5, 8.7, 8.9};
    static int[] prices = {300, 150, 250, 400, 200, 350, 100};
    static String[] times = {"09:00", "10:30", "12:00", "14:15", "16:30", "18:45", "21:00"};

    static int linearSearch(String target) {
        for (int i = 0; i < movies.length; i++)
            if (movies[i].equalsIgnoreCase(target)) return i;
        return -1;
    }

    static void showMovies() {
        for (int i = 0; i < movies.length; i++) {
            System.out.println((i+1) + ". " + movies[i] + " Rs." + prices[i]);
        }
    }
}
